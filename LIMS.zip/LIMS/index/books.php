 
<?php
ob_start();
 
 include '../dbcon.php';
 ?>
 


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Template Mo">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">   


    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-edu-meeting.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/lightbox.css">
    <link rel="icon"  href="title.jpg">  
    <title>Books</title>
<!--

TemplateMo 569 Edu Meeting

https://templatemo.com/tm-569-edu-meeting

-->
 <style>
   .heading-pages{
    background-image: url(book4.jpg) !important;
   }
 </style>
  </head>

<body>

   

 <!-- Sub Header -->
 <div class="sub-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-sm-8">
          <div class="left-content">
            <p>Daffodil<em> International</em> University</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-4">
          <div class="right-icons">
            <ul>
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-behance"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
      <div class="container">
          <div class="row">
              <div class="col-12">
                  <nav class="main-nav">
                      <!-- ***** Logo Start ***** -->
                     <!-- ***** Logo Start ***** -->
                     <a href="index.html" class="logo">
                          DIU Library
                      </a>
                      <!-- ***** Logo End ***** -->
                      <!-- ***** Menu Start ***** -->
                      <ul class="nav">
                          <li><a href="index1.php"  >Home</a></li>
                          <!-- <li><a href="meetings.html">Meetings</a></li> -->
                         
                          <!-- <li class="has-sub">
                              <a href="javascript:void(0)">Pages</a>
                              <ul class="sub-menu">
                                  <li><a href="meetings.html">Upcoming Meetings</a></li>
                                  <li><a href="meeting-details.html">Meeting Details</a></li>
                              </ul>
                          </li> -->
                          <li><a href="books.php" class="active">Books</a></li> 
                          <li><a href="upcomings.php">Upcoming Books</a></li> 
                          <li ><a href="contacts.php">Contact Us</a></li> 
                          <li><a href="../student/profile.php" class="btn"style="background: rgba(255, 99, 71, 0.8);
    text-align: center;
    border: none;
    border-radius: 10%;
    padding-bottom: 41px;">Profile</a></li>
                      </ul>      
                      <a class='menu-trigger'>
                          <span>Menu</span>
                      </a>
                      <!-- ***** Menu End ***** -->
                  </nav>
              </div>
          </div>
      </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <section class="heading-page header-text heading-pages" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h6>Here are our All Books</h6>
          <h2>Books</h2>
        </div>
      </div>
    </div>
  </section>

  <section class="our-courses" id="courses">
  <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="section-heading">
            <h2>Our Popular Books</h2>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="owl-courses-item owl-carousel">
            <?php 
             

             $query="SELECT * FROM books";
$all_books=mysqli_query($db,$query);
while($row=mysqli_fetch_assoc( $all_books) ){
 $book_image=$row['book_image'];
            $book_name=$row['book_name'];
            $available_qty=$row['available_qty'];
            ?>
             <!-- slider -->
            <div class="item">
              <?php
              if($book_image==""){ ?>
                            
                         <img style="height: 200px;"alt="profile photo" src="../files/photo/default.png" />
                    <?php   
                   } else{ ?>
                          <img style="height: 200px;" src="../imgbook/photo/<?php echo $book_image;?>"  alt="Book photo" >  
                         
                            
                          
                   <?php    
                     } 
                    ?>
                     
              <!-- <img src="assets/images/course-01.jpg" alt="Course One"> -->
              <div class="down-content">
                <h4><?php echo $book_name;?></h4>
                <div class="info">
                  <div class="row">
                    <div class="col-8">
                      <!-- <ul>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                      </ul> -->
                      Available:
                    </div>
                    <div class="col-4">
                       <span><?php echo $available_qty;?></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
             


             <!-- slider -->

           <?php }?>
          </div>
        </div>
      </div>
    </div>
    

  </section>
 
  
  <section class="contact-us" id="contact" style="padding: 1px 0px 0px 0px;">
     
    <div class="footer" style="text-align: center;
  
    border-top: 1px solid rgba(250,250,250,0.15);">
     <p>© 2022 DIU Library. 
           </p>
    </div>
  </section>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/isotope.min.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/lightbox.js"></script>
    <script src="assets/js/tabs.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/video.js"></script>
    <script src="assets/js/slick-slider.js"></script>
    <script src="assets/js/custom.js"></script>
    <script>
        //according to loftblog tut
        $('.nav li:first').addClass('active');

        var showSection = function showSection(section, isAnimate) {
          var
          direction = section.replace(/#/, ''),
          reqSection = $('.section').filter('[data-section="' + direction + '"]'),
          reqSectionPos = reqSection.offset().top - 0;

          if (isAnimate) {
            $('body, html').animate({
              scrollTop: reqSectionPos },
            800);
          } else {
            $('body, html').scrollTop(reqSectionPos);
          }

        };

        var checkSection = function checkSection() {
          $('.section').each(function () {
            var
            $this = $(this),
            topEdge = $this.offset().top - 80,
            bottomEdge = topEdge + $this.height(),
            wScroll = $(window).scrollTop();
            if (topEdge < wScroll && bottomEdge > wScroll) {
              var
              currentId = $this.data('section'),
              reqLink = $('a').filter('[href*=\\#' + currentId + ']');
              reqLink.closest('li').addClass('active').
              siblings().removeClass('active');
            }
          });
        };

        $('.main-menu, .responsive-menu, .scroll-to-section').on('click', 'a', function (e) {
          e.preventDefault();
          showSection($(this).attr('href'), true);
        });

        $(window).scroll(function () {
          checkSection();
        });



        document.addEventListener("contextmenu", function(e){
    e.preventDefault();
});
document.onkeydown = function(e){
    if(event.keyCode == 123){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.keyCode == "U".charCodeAt(0)){
        return false;
    }
}
    </script>
</body>


  </body>

</html>
<?php
 ob_end_flush();
 
 ?>