 
 
 
<?php
ob_start();
 
 include '../dbcon.php';
 ?>









<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="TemplateMo">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <!-- <link rel="stylesheet" type="text/css"  href="diu.png" title="Diu Library"> -->
    <!-- <title>Education Meeting HTML5 Template</title> -->
    <!-- font cdn -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">   
 <!-- Bootstrap core CSS -->
 
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-edu-meeting.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/lightbox.css">
     
    <link rel="icon"  href="title.jpg">  
    <title>Home</title>
   
<!--

TemplateMo 569 Edu Meeting

https://templatemo.com/tm-569-edu-meeting

-->
  </head>

<body>

  <!-- Sub Header -->
  <div class="sub-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-sm-8">
          <div class="left-content">
            <p>Daffodil<em> International</em> University</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-4">
          <div class="right-icons">
            <ul>
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-behance"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
      <div class="container">
          <div class="row">
              <div class="col-12">
                  <nav class="main-nav">
                      <!-- ***** Logo Start ***** -->
                      <a href="index.html" class="logo">
                          DIU Library
                      </a>
                      <!-- ***** Logo End ***** -->
                      <!-- ***** Menu Start ***** -->
                      <ul class="nav">
                          <li><a href="index1.php" class="active">Home</a></li>
                          <!-- <li><a href="meetings.html">Meetings</a></li> -->
                         
                          <!-- <li class="has-sub">
                              <a href="javascript:void(0)">Pages</a>
                              <ul class="sub-menu">
                                  <li><a href="meetings.html">Upcoming Meetings</a></li>
                                  <li><a href="meeting-details.html">Meeting Details</a></li>
                              </ul>
                          </li> -->
                          <li><a href="books.php">Books</a></li> 
                          <li><a href="upcomings.php">Upcoming Books</a></li> 
                          <li ><a href="contacts.php">Contact Us</a></li> 
                          <li><a href="../student/profile.php" class="btn"style="background: rgba(255, 99, 71, 0.8);
    text-align: center;
    border: none;
    border-radius: 10%;
    padding-bottom: 41px;">Profile</a></li>
                      </ul>        
                      <a class='menu-trigger'>
                          <span>Menu</span>
                      </a>
                      <!-- ***** Menu End ***** -->
                  </nav>
              </div>
          </div>
      </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <!-- ***** Main Banner Area Start ***** -->
  <section class="section main-banner" id="top" data-section="section1">
      <video autoplay muted loop id="bg-video">
          <source src="assets/images/diu.mp4" type="video/mp4" />
      </video>

      <div class="video-overlay header-text">
          <div class="container">
            <div class="row">
              <div class="col-lg-12">
                <div class="caption">
              <h6>Hello Students</h6>
              <h2>Welcome to DIU E-Library</h2>
              <p>At Daffodil International University, students get the opportunity to think, learn and grow.</p>
              <div class="main-button-red">
                  <div class=""><a href="../student/signin.php">Join Us Now!</a></div>
              </div>
          </div>
              </div>
            </div>
          </div>
      </div>
  </section>
  <!-- ***** Main Banner Area End ***** -->

  <section class="services">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="owl-service-item owl-carousel">
          
            <div class="item">
              <div class="icon">
                <img src="assets/images/service-icon-01.png" alt="">
              </div>
              <div class="down-content">
                <h4>Library</h4>
                <p>DIU library has a collection of over 50000 books, journals, research papers and enriching the resources day by day.</p>
              </div>
            </div>
            
            <div class="item">
              <div class="icon">
                <img src="assets/images/service-icon-02.png" alt="">
              </div>
              <div class="down-content">
                <h4>Programs</h4>
                <p>We are offering 36 undergraduate and graduate programs under 25 departments. Our curriculum is designed to help the students to develop the skills required for 21st-century employment.</p>
              </div>
            </div>
            
            <div class="item">
              <div class="icon">
                <img src="assets/images/service-icon-03.png" alt="">
              </div>
              <div class="down-content">
                <h4>Admission</h4>
                <p>We have students coming from different backgrounds, cultures, and nationalities as well. More than 500 international students are enrolled in various programs.</p>
              </div>
            </div>
            
            <div class="item">
              <div class="icon">
                <img src="assets/images/service-icon-02.png" alt="">
              </div>
              <div class="down-content">
                <h4>Blended Learning Platform</h4>
                <p>To engage students in learning after face-to-face classes, our faculty members and students collaborate in the online.</p>
              </div>
            </div>
            
            <div class="item">
              <div class="icon">
                <img src="assets/images/service-icon-03.png" alt="">
              </div>
              <div class="down-content">
                <h4>Accommodation</h4>
                <p>We are providing a secure and convenient living facility for our students. DIU dormitories are a home away from home.</p>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="upcoming-meetings" id="meetings">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="section-heading">
            <h2>Upcoming Books</h2>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="categories">
            <h4>Book Catgories</h4>
            <ul>
              <li><a href="../student/books.php">Story</a></li><br>
              <li><a href="../student/books.php">Litaratue </a></li><br>
              <li><a href="../student/books.php">Language</a></li><br>
              <li><a href="../student/books.php">Horror</a></li><br>
             
            </ul>
            <div class="main-button-red">
              <a href="upcoming.php">All Upcoming Books</a>
            </div>
          </div>
        </div>
        <div class="col-lg-8">
          <div class="row">
            <div class="col-lg-6">
              <div class="meeting-item">
                <div class="thumb">
                  <div class="price">
                    <span>Pro</span>
                  </div>
                  <a href="../student/register_online_book.php"><img src="b1.jpg" style="height: 240px;" alt="New Lecturer Meeting"></a>
                </div>
                <div class="down-content">
                  <div class="date">
                    <h6>Nov <span>10</span></h6>
                  </div>
                  <a href="../student/register_online_book.php"><h4>Ga Chomchome Bhut</h4></a>
                  <p>গা ছমছমে ভূতের গল্প, ভূতের উপন্যাস, হরর কাহিনী, জনপ্রিয় ভূতের কাহিনী পড়ুন এখনি .</p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="meeting-item">
                <div class="thumb">
                  <div class="price">
                    <span>Pro</span>
                  </div>
                  <a href="../student/register_online_book.php"><img src="b2.jpg"style="height: 210px;" alt="Online Teaching"></a>
                </div>
                <div class="down-content">
                  <div class="date">
                    <h6>Nov <span>24</span></h6>
                  </div>
                  <a href="../student/register_online_book.php"><h4>Purbo-Banglar Galpo</h4></a>
                  <p>রবীন্দ্রনাথ ঠাকুরের বহুল পঠিত ও জনপ্রিয় বাংলা বই, উপন্যাস, কবিতা, সংগীত, নাটকের বই, ভ্রমনকাহিনী, প্রবন্ধ</p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="meeting-item">
                <div class="thumb">
                  <div class="price">
                    <span>Pro</span>
                  </div>
                  <a href="../student/register_online_book.php"><img src="b3.jpg" style="height: 240px;"alt="Higher Education"></a>
                </div>
                <div class="down-content">
                  <div class="date">
                    <h6>Nov <span>26</span></h6>
                  </div>
                  <a href="../student/register_online_book.php"><h4>Botuk Buror Chasma</h4></a>
                  <p>শীর্ষেন্দু মুখোপাধ্যায় জনপ্রিয় বই, বাংলা উপন্যাস, জনপ্রিয় বাংলা উপন্যাস, প্রেমের উপন্যাস, প্রেমের গল্প, ভ্রমন কাহিনী </p>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="meeting-item">
                <div class="thumb">
                  <div class="price">
                    <!-- <span> </span> -->
                  </div>
                  <a href="../student/books.php"><img src="p4.jpg" style="height: 240px;alt="Student Training"></a>
                </div>
                <div class="down-content">
                  <div class="date">
                    <h6>Nov <span>30</span></h6>
                  </div>
                  <a href="../student/books.php"><h4>Himu</h4></a>
                  <p>হুমায়ুন আহমেদ এর জনপ্রিয় উপন্যাস ,প্রেমের উপন্যাস, বাংলা বই, বাংলা উপন্যাস, ভ্রমণ কাহিনী, মুক্তিযুদ্ধের উপন্যাস, হিমু সিরিজ, মিসির আলী </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="apply-now" id="apply">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 align-self-center">
          <div class="row">
            <div class="col-lg-12">
              <div class="item">
                <h3>Issue Book</h3>
                <p>If you issue any book then contact the register office.If you see all the book then register. </p>
                <div class="main-button-red">
                  <div class=""><a href="../student/books.php">Join Us Now!</a></div>
              </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="item">
                <h3>Online E-Book</h3>
                <p>You can easly download any book, if you percese online facielity.</p>
                <div class="main-button-yellow">
                  <div class=""><a href="../student/register_online_book.php">Join Us Now!</a></div>
              </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="accordions is-first-expanded">
            <article class="accordion">
                <div class="accordion-head">
                    <span>Where to download E-book?</span>
                    <span class="icon">
                        <i class="icon fa fa-chevron-right"></i>
                    </span>
                </div>
                <div class="accordion-body">
                    <div class="content">
                        <p>To download e-books please go the the following link. You need to login with your e-book identity and password to search or download e-books.</p>
                    </div>
                </div>
            </article>
            <article class="accordion">
                <div class="accordion-head">
                    <span>How can i pay my fees?</span>
                    <span class="icon">
                        <i class="icon fa fa-chevron-right"></i>
                    </span>
                </div>
                <div class="accordion-body">
                    <div class="content">
                        <p>You can pay your fees by selecting payment option. First login with your id and password.then click on payment and pay your dues.</p>
                    </div>
                </div>
            </article>
            <article class="accordion">
                <div class="accordion-head">
                    <span>Can i register myself?</span>
                    <span class="icon">
                        <i class="icon fa fa-chevron-right"></i>
                    </span>
                </div>
                <div class="accordion-body">
                    <div class="content">
                        <p>Yes, This is a self registered website you can register by using registration form</p>
                    </div>
                </div>
            </article>
            <article class="accordion last-accordion">
                <div class="accordion-head">
                    <span>How many day i can hold my book?</span>
                    <span class="icon">
                        <i class="icon fa fa-chevron-right"></i>
                    </span>
                </div>
                <div class="accordion-body">
                    <div class="content">
                    <p>You can hold 7 days after taking the book</p>  
                  </div>
                </div>
            </article>
        </div>
        </div>
      </div>
    </div>
  </section>

  
  <!-- feed back -->
 
  <?php

// SELECT students.CONCAT(fname+''+lname) as fullname, rate.userName as ratename
// FROM students
// INNER JOIN rate ON fullname=ratename;

//  SELECT students.id,students.fname,students.lname, rate.userName,rate.userMessage
// FROM students CONCAT(students.fname, ' ', students.lname)='Meharaz Hossain'AND rate.userName='Meharaz Hossain'
// INNER JOIN rate ON  CONCAT(students.fname, ' ', students.lname)=rate.userName
// $query="SELECT students.id,students.fname,students.lname, rate.userName,rate.userMessage,rate.dateReviewed
// FROM students
// INNER JOIN rate ON CONCAT(students.fname, ' ', students.lname)=rate.userName ";
//  CONCAT(students.fname,students.lname)
// $all_users=mysqli_query($db,$query);
// while($row=mysqli_fetch_assoc($all_users)){
//       $userName=$row['userName'];
//       $userMessage=$row['userMessage'];
// }
       ?>

 
  <!-- feedback -->

  <section class="our-facts">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="row">
            <div class="col-lg-12">
              <h2>A Few Facts About Our E-library</h2>
            </div>
            <div class="col-lg-6">
              <div class="row">
                <div class="col-12">
                  <div class="count-area-content percentage">
                    <div class="count-digit">94</div>
                    <div class="count-title">Feedback</div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="count-area-content">
                    <div class="count-digit">200</div>
                    <div class="count-title">Paid Students</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="row">
                <div class="col-12">
                  <div class="count-area-content">
                    <div class="count-digit">120</div>
                    <div class="count-title">New Students</div>
                  </div>
                </div> 
                <div class="col-12">
                  <div class="count-area-content">
                    <div class="count-digit">200</div>
                    <div class="count-title">Total Students</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div> 
        <div class="col-lg-6 align-self-center">
          <div class="video">
            <a href="https://www.youtube.com/watch?v=DabdORZgpE8" target="_blank"><img src="assets/images/play-icon.png" alt=""></a>
          </div>
        </div>
      </div>
    </div>
     
  </section>
 
  <section class="contact-us" id="contact" style="padding: 1px 0px 0px 0px;">
     
    <div class="footer" style="text-align: center;
  
    border-top: 1px solid rgba(250,250,250,0.15);">
     <p>© 2022 DIU Library. 
           </p>
    </div>
  </section>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/isotope.min.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/lightbox.js"></script>
    <script src="assets/js/tabs.js"></script>
    <script src="assets/js/video.js"></script>
    <script src="assets/js/slick-slider.js"></script>
    <script src="assets/js/custom.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" ></script>
    <script>
        //according to loftblog tut
        $('.nav li:first').addClass('active');

        var showSection = function showSection(section, isAnimate) {
          var
          direction = section.replace(/#/, ''),
          reqSection = $('.section').filter('[data-section="' + direction + '"]'),
          reqSectionPos = reqSection.offset().top - 0;

          if (isAnimate) {
            $('body, html').animate({
              scrollTop: reqSectionPos },
            800);
          } else {
            $('body, html').scrollTop(reqSectionPos);
          }

        };

        var checkSection = function checkSection() {
          $('.section').each(function () {
            var
            $this = $(this),
            topEdge = $this.offset().top - 80,
            bottomEdge = topEdge + $this.height(),
            wScroll = $(window).scrollTop();
            if (topEdge < wScroll && bottomEdge > wScroll) {
              var
              currentId = $this.data('section'),
              reqLink = $('a').filter('[href*=\\#' + currentId + ']');
              reqLink.closest('li').addClass('active').
              siblings().removeClass('active');
            }
          });
        };

        $('.main-menu, .responsive-menu, .scroll-to-section').on('click', 'a', function (e) {
          e.preventDefault();
          showSection($(this).attr('href'), true);
        });

        $(window).scroll(function () {
          checkSection();
        });

    


//         document.addEventListener("contextmenu", function(e){
//     e.preventDefault();
// });
 
document.addEventListener("contextmenu", function(e){
    e.preventDefault();
});
document.onkeydown = function(e){
    if(event.keyCode == 123){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.keyCode == "U".charCodeAt(0)){
        return false;
    }
}
  
 
    </script>
</body>

</body>
</html>

<?php
 ob_end_flush();
 
 ?>