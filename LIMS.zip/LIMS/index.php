<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
	<style >
		body{
			 background: url(image/mbg.jpg) no-repeat center center fixed; 
			  -webkit-background-size: cover;
			  -moz-background-size: cover;
			  -o-background-size: cover;
			  background-size: cover;
			 
		}

		.cssmarquee {
height: 50px;
overflow: hidden;
position: relative;
}
.cssmarquee h1 {
font-size: 2em;
    color: #ca2e3c;
    position: absolute;
    width: 100%;
    height: 100%;
    font-weight: 600;
    margin: 0;
    line-height: 50px;
    text-align: center;
    transform: translateX(100%);
    animation: cssmarquee 10s linear infinite;
}
.button {
	height: 45px;
    font-family: 'Roboto', sans-serif;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 2.5px;
    font-weight: 500;
    color: #FFF;
    background-color: red;
    border: none;
    border-radius: 45px;
    /* box-shadow: 0px 8px 15px rgb(0 0 0 / 10%); */
	box-shadow: rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset;
    transition: all 0.3s ease 0s;
    cursor: pointer;
    outline: none;
    text-align: center;
    padding-top: 13px;
    font-size: 14px;
}

.button:hover {
  background-color: #2EE59D;
  box-shadow: 0px 15px 20px rgba(46, 229, 157, 0.4);
  color: #fff;
  transform: translateY(-7px);
}
@keyframes cssmarquee {
0% {
transform: translateX(100%);
}
100% {
transform: translateX(-100%);
}
}
		 
	</style>
</head>
<body>
	 
	 
	<div class="container ">
		<div class="row ">
			<div class="col-sm-4 col-sm-offset-4 justify-content-center">
				<div class="cssmarquee">
				<h1>Welcome! DIU Library</h1>
				</div>
								<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<!-- <a href="student/index.php" title="" class="btn btn-primary btn-block">Student</a> -->
				<a href="librarian/index.php" title="" class="btn btn-primary btn-block button"><i class="uil uil-book-reader"></i> Librarian</a>
			</div>
			<div class="col-md-4">


			  
			</div>
		</div>
	</div>
	<script>
// 		document.addEventListener("contextmenu", function(e){
//     e.preventDefault();
// });
// document.onkeydown = function(e){
//     if(event.keyCode == 123){
//         return false;
//     }
//     if(e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)){
//         return false;
//     }
//     if(e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)){
//         return false;
//     }
//     if(e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)){
//         return false;
//     }
//     if(e.ctrlKey && e.keyCode == "U".charCodeAt(0)){
//         return false;
//     }
// }

	</script>
 
</body>
</html>