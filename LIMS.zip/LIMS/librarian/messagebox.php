<?php
 ob_start();
  
 include '../dbcon.php';
 include 'header.php';
  
 ?>




<div class="content">
                <div class="content-header">
                    <!-- leftside content header -->
                    <div class="leftside-content-header">
                        <ul class="breadcrumbs">
                            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                        <li> <a href="messagebox.php">Message box</a></li>
                        </ul>
                        <ul>
                        	
                        </ul>
                    </div>
                </div>


<div class="row animated fadeInUp">
    
 
  <div class="col-sm-12">
                    <h4 class="section-subtitle"><b>All Faq Message</b></h4>
                    <div class="panel">
                        <div class="panel-content">
                            <div class="table-responsive">
                                <table id="basic-table" class="data-table table table-striped nowrap table-hover" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>Full Name</th>
                                        
                                        <th>Email</th>
                                        <th>Message</th>
                                         <th>Date</th>                                  
                                        
                                        <th>Action</th>
                                    </tr>
                                    </thead> 
                                     

                                    
                              <?php

   
                                     $query="SELECT * FROM messagebox WHERE status='0'";
                            $all_students=mysqli_query($db,$query);
                            while($row=mysqli_fetch_assoc($all_students) ){
                                $id=$row['id'];
                                   $name=$row['name'];
                                  $email=$row['email'];
                                  $message=$row['message'];                             
                                  $datetime=$row['datetime'];
                                
                           

                                   ?>


                                    <tbody>  
                                    <td> <?php echo $name;?></td>
                                        <!-- <td><?php// echo $i;?></td> -->
                                        <td>
                                            <?php echo $email;?>

  
                      

                                        </td>
                                        
                                        <td><?php echo $message;?></td>
                                         
                                      <td><?php echo date('d-M-Y',strtotime($datetime));?></td>
                                        <td>   
                                        
                                        <a href="messagebox.php?seenid=<?php echo $id;?>" title=""class="btn btn-info btn-sm"> <i class="fas fa-eye"></i>   </a>

 
                         


                                                            


                                         
                                     </td>
                                         

                                     
                                    </tbody>

                               <?php  }
                                ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                
                <?php

if (isset($_GET['seenid'])) {
        

    $id= $_GET['seenid'];
    $query="update messagebox set status='1' where id='$id'";
    $all_message=mysqli_query($db,$query);
    if($all_message){
        echo "<script>window.location='messagebox.php'</script>";
    }

}


?>


</div>








<div class="row animated fadeInUp">
    
 
  <div class="col-sm-12">
                    <h4 class="section-subtitle"><b>All Home Message</b></h4>
                    <div class="panel">
                        <div class="panel-content">
                            <div class="table-responsive">
                                <table id="basic-table" class="data-table table table-striped nowrap table-hover" cellspacing="0" width="100%">
                                    <thead>
                                    <tr>
                                        <th>Full Name</th>
                                        
                                        <th>Email</th>
                                        <th>Subject</th>
                                        <th>Message</th>
                                         <th>Date</th>                                  
                                        
                                        <th>Action</th>
                                    </tr>
                                    </thead> 
                                     

                                    
                              <?php

   
                                     $querys="SELECT * FROM query_message WHERE status='0'";
                            $all_students_q=mysqli_query($db,$querys);
                            while($row=mysqli_fetch_assoc($all_students_q) ){
                                $ids=$row['id'];
                                   $names=$row['name'];
                                  $emails=$row['email'];
                                  $subject=$row['subject'];    
                                  $messages=$row['message'];                             
                                  $datetimes=$row['date'];
                                
                           

                                   ?>


                                    <tbody>  
                                    <td> <?php echo $names;?></td>
                                        <!-- <td><?php// echo $i;?></td> -->
                                        <td>
                                            <?php echo $emails;?>

  
                      

                                        </td>
                                        <td><?php echo $subject;?></td>
                                        
                                        <td><?php echo $messages;?></td>
                                         
                                      <td><?php echo date('F j, Y, g:i a',strtotime($datetimes));?></td>
                                        <td>   
                                        
                                        <a href="messagebox.php?qid=<?php echo $ids;?>" title=""class="btn btn-info btn-sm"> <i class="fas fa-eye"></i>   </a>

 
                         


                                                            


                                         
                                     </td>
                                         

                                     
                                    </tbody>

                               <?php  }
                                ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <?php

if (isset($_GET['qid'])) {
        

    $ids= $_GET['qid'];
    $querys="update query_message set status='1' where id='$ids'";
    $all_messages=mysqli_query($db,$querys);
    if($all_messages){
        echo "<script>window.location='messagebox.php'</script>";
    }

}


?>
</div>























 

                <!---data table end--->


   




 




















                  </div>
              













 <?php
 include 'footer.php';
 ?>
   

<?php
ob_end_flush();


?>