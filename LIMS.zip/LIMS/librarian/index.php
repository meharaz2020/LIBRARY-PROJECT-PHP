 <?php
 ob_start();
  
 include '../dbcon.php';
 include 'header.php';
 ?>
 
  
                <!-- ========================================================= -->
                 <div class="content">
                <div class="content-header">
                    <!-- leftside content header -->
                    <div class="leftside-content-header">
                        <ul class="breadcrumbs">
                            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                        </ul>
                    </div>
                </div>
               <div style="margin-top:25px;"class="row  ">
    
                    <!--BOX Style 1-->
                    <?php
                    $re=mysqli_query($db,"SELECT * FROM students");
                   
                    $st=mysqli_num_rows($re);
                    ?>
                       <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-info color-light">
                            <a href="students.php">
                                <div class="panel-content">
                                    <h1 class="title color-light"> <i class="fa fa-users"></i> <?php  echo $st; ?> </h1>
                                    <h4 class="subtitle color-light">Total Student</h4>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php
                    $ore=mysqli_query($db,"SELECT * FROM bkashonlinebook");
                   
                    $ost=mysqli_num_rows($ore);
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-success color-light">
                            <a href="pro_user.php">
                                <div class="panel-content">
                                    <h1 class="title color-light"> <i class="fa fa-users"></i> <?php  echo $ost; ?> </h1>
                                    <h4 class="subtitle color-light">Total Paid Student </h4>
                                </div>
                            </a>
                        </div>
                    </div>
                    <!--BOX Style 1-->
                     <?php
                    $mre=mysqli_query($db,"SELECT * FROM messagebox WHERE status='0'");
                   
                    $mst=mysqli_num_rows($mre);
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-danger color-light">
                            <a href="messagebox.php">
                                <div class="panel-content">
                                    <h1 class="title color-light-1"> <i class="fa fa-envelope"></i> <?php  echo $mst; ?> </h1>
                                    <h4 class="subtitle">New Messages</h4>
                                </div>
                            </a>
                        </div>
                    </div>
                    <!--BOX Style 1-->
                    <?php
                    $mres=mysqli_query($db,"SELECT * FROM query_message WHERE status='0'");
                   
                    $msts=mysqli_num_rows($mres);
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-darker-2 color-light">
                            <a href="messagebox.php">
                                <div class="panel-content">
                                    <h1 class="title color-light-1"> <i class="fa fa-envelope"></i> <?php  echo $msts; ?> </h1>
                                    <h4 class="subtitle" style="font-size:16px">New Home Messages</h4>
                                </div>
                            </a>
                        </div>
                    </div>
                  
                    <!--BOX Style 1-->
                    <?php
                    $bre=mysqli_query($db,"SELECT * FROM books");
                   
                    $bst=mysqli_num_rows($bre);
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-warning color-light">
                            <a href="books.php">
                                <div class="panel-content">
                                   <h1 class="title color-light-1"> <i class="fas fa-book-open"></i>&nbsp;<?php  echo $bst; ?> </h1>
                                    <h4 class="subtitle">Total Books</h4>
                                </div>
                            </a>
                        </div>
                    </div>

                       <!--BOX Style 1-->
                       <?php
                    $ore1=mysqli_query($db,"SELECT * FROM bkashonlinebook");
                   
                    $ost1=mysqli_num_rows($ore1);
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-info color-light">
                            <a href="pro_user.php">
                                <div class="panel-content">
                                   <h1 class="title color-light-1"> &#2547; &nbsp;<?php  echo $ost1*550 ; ?> </h1>
                                    <h4 class="subtitle">Total Earning</h4>
                                </div>
                            </a>
                        </div>
                    </div>

                    <!--BOX Style 1-->
                    <?php
                    $bre=mysqli_query($db,"SELECT sum(book_qty) as tbook FROM books");
                   
                    $userData=mysqli_fetch_assoc($bre);
                    $tbook= $userData['tbook'];
                    
                       
                    
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-success color-light">
                            <a href="books.php">
                                <div class="panel-content">
                                   <h1 class="title color-light-1"> <i class="fas fa-book-open"></i>&nbsp;<?php  echo $tbook; ?> </h1>
                                    <h4 class="subtitle">Books Available</h4>
                                </div>
                            </a>
                        </div>
                    </div>


                    <!--BOX Style 1-->
                    <?php
                   $bre5=mysqli_query($db,"SELECT * FROM students WHERE status=1");
                   
                   $bst5=mysqli_num_rows($bre5);
                       
                    
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-danger color-light">
                            <a href="students.php">
                                <div class="panel-content">
                                   <h1 class="title color-light-1"> <i class="fas fa-solid fa-user-check"></i>&nbsp;<?php  echo $bst5; ?> </h1>
                                    <h4 class="subtitle">Active Students</h4>
                                </div>
                            </a>
                        </div>
                    </div>

                    <!--BOX Style 1-->
                    <?php
                    
                    $bre4=mysqli_query($db,"SELECT * FROM students WHERE status=0");
                   
                    $bst4=mysqli_num_rows($bre4);
                       
                    
                    ?>
                    <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-darker-2 color-light">
                            <a href="students.php">
                                <div class="panel-content">
                                   <h1 class="title color-light-1"> <i class="fas fa-solid fa-users-slash"></i>&nbsp;<?php  echo $bst4; ?> </h1>
                                    <h4 class="subtitle">Inactive Students</h4>
                                </div>
                            </a>
                        </div>
                    </div>

                     <!--BOX Style 1-->
                     <?php
                     $time=time();
                     $time_out_in_seconds=20;
                     $time_out=$time - $time_out_in_seconds;
                        $user_online_query=mysqli_query($db,"SELECT * FROM user_online WHERE time > '$time_out'");

                        $count_user=mysqli_num_rows($user_online_query);
                        ?>
                    <div class="col-sm-6 col-md-4 col-lg-2" style="margin-right: 20px;">
                        <div class="panel widgetbox wbox-1 bg-warning color-light">
                            <a href="students.php">
                                <div class="panel-content">
                                   <h1 class="title color-light-1"> <i class="fas fa-solid fa-signal"></i>&nbsp;<?php  echo  $count_user; ?> </h1>
                                    <h4 class="subtitle">Online Active</h4>
                                </div>
                            </a>
                        </div>
                    </div>

      

<!-- 
chart -->


              <div class="col-sm-12 col-md-6">
               <table class="graph">
                <?php
                    $req=mysqli_query($db,"SELECT * FROM students");
                   
                    $stq=mysqli_num_rows($req);
                    ?>
 
    <thead>
        <tr>
            <th scope="col">Item</th>
            <th scope="col">Percent</th>
        </tr>
    </thead><tbody>
        <tr style="height:<?php echo $stq*5;?>%">
            <th scope="row">Students</th>
            <td><span><?php echo $stq*5;?>%</span></td>
        </tr>
        <?php
                    $pore=mysqli_query($db,"SELECT * FROM bkashonlinebook");
                   
                    $post=mysqli_num_rows($pore);
                    ?>
        <tr style="height:<?php echo $post*5;?>%">
            <th scope="row">Paid Students</th>
            <td><span><?php echo $post*5;?>%</span></td>
        </tr>
         
    </tbody>
</table>

  
                </div>

                 <div class="col-sm-12 col-md-6 ">
                    
                
                 <div style="position: absolute;
"class="img">
                     <a target="_blank"href="https://www.google.com/maps/place/Daffodil+International+University+(DIU)/@23.7549184,90.3741778,17z/data=!3m1!4b1!4m5!3m4!1s0x3755b8ada2664e21:0x3c872fd17bc11ddb!8m2!3d23.7549184!4d90.3763665" title=""><img style="height: 342px;
    width: 468px;
    position: relative;
    left: 73px;
"src="../image/map.png" alt=""></a>
                 </div>
             </div>

  
                  
         <div class="col-lg-12">
         <div class="col-sm-12 col-md-12">
               <table class="graph">
     
                     <?php
                    // $brej=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook");
                   
                    // $userDataj=mysqli_fetch_assoc($brej);
                    // $j= $userDataj['Month'];
                    
                       
                    
                    ?>
 
    <thead>
        <tr>
            <th scope="col">Item</th>
            <th scope="col">Percent</th>
        </tr>
    </thead><tbody>

        <tr style="height:<?php  

$pore=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=1");
                   
$post1=mysqli_num_rows($pore);
 
    echo  $post1 * 5;
 
        
        ?>%">
            <th scope="row">January</th>
            <td><span style="color: red;"><?php 
            $pore=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=1");
                   
            $post1=mysqli_num_rows($pore);
             
                echo  $post1 * 550;
            
            ?>&#2547;</span></td>
        </tr>
        
        <?php
                  
                    
                       
                    
                    ?>
        <tr style="height:<?php 
        $pore2=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=2");
                   
        $post2=mysqli_num_rows($pore2);
         
            echo  $post2 * 5;
        ?>%">
            <th scope="row">February</th>
            <td><span style="color: red;"><?php 
            
            $pore2=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=2");
                   
            $post2=mysqli_num_rows($pore2);
             
                echo  $post2 * 550;
            
              
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php 
        $pore3=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=3");
                   
        $post3=mysqli_num_rows($pore3);
         
            echo  $post3 * 5;
        ?>%">
            <th scope="row">March</th>
            <td><span style="color: red;"><?php 
             $pore3=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=3");
                   
             $post3=mysqli_num_rows($pore3);
              
                 echo  $post3 * 550;
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php 
        $pore4=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=4");
                   
        $post4=mysqli_num_rows($pore4);
         
            echo  $post4 * 5;
        ?>%">
            <th scope="row">April</th>
            <td><span style="color: red;"><?php 
            $pore4=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=4");
                   
            $post4=mysqli_num_rows($pore4);
             
                echo  $post4 * 5;
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php 
               $pore5=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=5");
                   
               $post5=mysqli_num_rows($pore5);
                
                   echo  $post5 * 5;
        ?>%">
            <th scope="row">May</th>
            <td><span style="color: red;"><?php  
                   $pore5=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=5");
                   
                   $post5=mysqli_num_rows($pore5);
                    
                       echo  $post5 * 550;
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php
        $pore6=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=6");
                   
        $post6=mysqli_num_rows($pore6);
         
            echo  $post5 * 5;
        ?>%">
            <th scope="row">June</th>
            <td><span style="color: red;"><?php  
            $pore6=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=6");
                   
            $post6=mysqli_num_rows($pore6);
             
                echo  $post5 * 550;
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php 
         $pore7=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=7");
                   
         $post7=mysqli_num_rows($pore7);
          
             echo  $post5 * 5;
        ?>%">
            <th scope="row">July</th>
            <td><span style="color: red;"><?php 
             $pore7=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=7");
                   
             $post7=mysqli_num_rows($pore7);
              
                 echo  $post5 * 550;
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php  
         $pore8=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=8");
                   
         $post8=mysqli_num_rows($pore8);
          
             echo  $post5 * 5;
        ?>%">
            <th scope="row">August</th>
            <td><span style="color: red;"><?php  
            $pore8=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=8");
                   
            $post8=mysqli_num_rows($pore8);
             
                echo  $post5 * 550;
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php 
         $pore9=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=9");
                   
         $post9=mysqli_num_rows($pore9);
          
             echo  $post5 * 5;
        ?>%">
            <th scope="row">September</th>
            <td><span style="color: red;"><?php  
            $pore9=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=9");
                   
            $post9=mysqli_num_rows($pore9);
             
                echo  $post5 * 550;
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php  
        $pore10=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=10");
                   
        $post10=mysqli_num_rows($pore10);
         
            echo  $post5 * 5;
        ?>%">
            <th scope="row">October</th>
            <td><span style="color: red;"><?php  
            $pore10=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=10");
                   
            $post10=mysqli_num_rows($pore10);
             
                echo  $post5 * 550;
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php  
        $pore11=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=11");
                   
        $post11=mysqli_num_rows($pore11);
         
            echo  $post5 * 5;
        ?>%">
            <th scope="row">November</th>
            <td><span style="color: red;"><?php  
            $pore11=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=11");
                   
            $post11=mysqli_num_rows($pore11);
             
                echo  $post5 * 550;
            ?>&#2547;</span></td>
        </tr>
        <tr style="height:<?php 
        $pore12=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=12");
                   
        $post12=mysqli_num_rows($pore12);
         
            echo  $post5 * 5;
        ?>%">
            <th scope="row">December</th>
            <td><span style="color: red;"><?php  
             $pore12=mysqli_query($db,"SELECT MONTH(timedate) AS Month FROM bkashonlinebook where MONTH(timedate)=12");
                   
             $post12=mysqli_num_rows($pore12);
              
                 echo  $post5 * 550;
            ?>&#2547;</span></td>
        </tr>
         
    </tbody>
</table>

  
                </div>
         </div>



 




            
            <!--scroll to top-->
            <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
        </div>
    </div>

  </div>  
       

               
  </div>











  <?php
 include 'footer.php';
 ?>
   

<?php
ob_end_flush();


?>