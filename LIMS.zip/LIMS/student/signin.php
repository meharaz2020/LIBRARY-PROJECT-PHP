<?php
session_start();
ob_start();
include '../dbcon.php';
if(isset($_SESSION['student_id'] )){
header('Location: index.php');
}



?>
 
 <?php







     if(isset($_POST['signin'])){
        if (isset($_POST['checked'])) { 

            $email           =$_POST['email'];
             
            $password        =$_POST['password'];

           $email_check = mysqli_query($db,"SELECT * FROM students WHERE email = '$email' OR username = '$email'");
            
          if(mysqli_num_rows($email_check) > 0){
                         $row = mysqli_fetch_assoc($email_check);
                         if( password_verify($password, $row['password']) ){
                               if($row['status']==1){
                                $_SESSION['student_id'] = $row['id'];
                                  header("Location:index.php ");
                                }else{
                                  $status_error="Your status inactive!";
                                }
                         }else{
                               $password_error="Wrong Password";
                         }
                  }else{
                      $email_error="Wrong email or username id";
          }


    
   

            }else{
 $errors=  '<div class="alert alert-danger mt-3" role="alert">
  Please, check me out!
</div> ';
}

   }          



?>
<!doctype html>
<html lang="en" class="fixed accounts sign-in">


 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
 
    
    <!-- Bootstrap core CSS -->
    <link href="../index/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
     
    <!--BASIC css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="../assets/vendor/animate.css/animate.css">
    <!--SECTION css-->
    <!-- ========================================================= -->
    <!--TEMPLATE css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../assets/stylesheets/css/style.css">


    <link rel="stylesheet" href="../index/assets/css/fontawesome.css">
    <link rel="stylesheet" href="../index/assets/css/templatemo-edu-meeting.css">
    <link rel="stylesheet" href="../index/assets/css/owl.css">
    <link rel="stylesheet" href="../index/assets/css/lightbox.css">
    <link rel="icon"  href="../index/title.jpg">  
    <title>Log In</title>
    <style >
        .error{
  color: red;
  font-style: italic;
   
  font-weight: bold;

}
a:hover{
    background-color: transparent !important;
}
 
 /* .bg-img{
    max-width: 100%;
    max-height: 100%;
    background-image: url(../image/bg1.jpg);
    background-position: center;
    background-attachment: fixed;
    background-blend-mode: color-dodge;
    background-repeat: no-repeat;
 } */
 
   .heading-pagess{
    background-image: url(../index/signin.jpg) !important;
    background-position: top !important;
    background-repeat: no-repeat !important;
    background-size: cover !important;
    padding-top: 230px !important;
    padding-bottom:0 !important;
    text-align: center !important;
   }
   .header-area .main-nav .logo{
       line-height:0 !important;
       padding-top: 20px;
   }
   .header-area .main-nav .nav li a {
    line-height:0 !important;

   }
   .header-area .main-nav .nav li {
 padding-left: 0 !important;
     padding-right: 0 !important; 
}
        
    </style>
</head>

<body>



 <!-- Sub Header -->
 <div class="sub-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-sm-8">
          <div class="left-content">
            <p>Daffodil<em> International</em> University</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-4">
          <div class="right-icons">
            <ul>
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-behance"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky fixed-top">
      <div class="container">
          <div class="row">
              <div class="col-12">
                  <nav class="main-nav">
                      <!-- ***** Logo Start ***** -->
                     <!-- ***** Logo Start ***** -->
                     <a href="../index/index.html" class="logo">
                          DIU Library
                      </a>
                      <!-- ***** Logo End ***** -->
                      <!-- ***** Menu Start ***** -->
                      <ul class="nav">
                          <li><a href="../index/index.php"  >Home</a></li>
                          <!-- <li><a href="meetings.html">Meetings</a></li> -->
                         
                          <!-- <li class="has-sub">
                              <a href="javascript:void(0)">Pages</a>
                              <ul class="sub-menu">
                                  <li><a href="meetings.html">Upcoming Meetings</a></li>
                                  <li><a href="meeting-details.html">Meeting Details</a></li>
                              </ul>
                          </li> -->
                          <li><a href="../index/book.php">Books</a></li> 
                          <li><a href="../index/upcoming.php">Upcoming Books</a></li> 
                          <li ><a href="../index/contact.php">Contact Us</a></li> 
                          <li class=""><a href="../student/signin.php" class="active">Log In</a></li>
                      </ul>        
                      <a class='menu-trigger'>
                          <span>Menu</span>
                      </a>
                      <!-- ***** Menu End ***** -->
                  </nav>
              </div>
          </div>
      </div>
  </header>
  <!-- ***** Header Area End ***** -->

 <section class="heading-page header-text heading-pagess" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          
          <h2>Log In</h2>
        </div>
      </div>
    </div>
  </section> 











  <section class="our-courses" id="courses"
  
  style="padding-bottom:0px !important; padding-top:0px !important"
  >

    <div class="container"> 
<div class="wrap">
    <!-- page BODY -->
    <!-- ========================================================= -->
    <div class="page-body animated slideInDown bg-img">
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
        <!--LOGO-->
        <!-- <div class="logo">
            <h1 class="text-center" style="color: #FFF;
    font-weight: 600;"><a  style="text-decoration:none; cursor:pointer;" href="../index/index.php">DIU Library</a></h1>
        </div> -->
        <div class="col-sm-12  col-lg-12" style="text-align:center;">
                 <?php if(isset($status_error)){echo '<p class="alert alert-danger" role="alert col-sm-4 offset-sm-3">'.$status_error.'</p>';}?> 
            </div>
        <div class="col-lg-12">
            <div class="col-lg-6 col-md-6">
               <div class="row">
                   <img src="sign.png" alt="" style="padding-right: 79px;
    padding-top: 40px;">
               </div>
            </div>
            
       <div class="box col-lg-6 col-md-6" style="margin-bottom: 148px;">
              
            <!--SIGN IN FORM-->
            <div class="panel mb-none">
                <div class="panel-content bg-scale-0">
                  
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="form-group mt-md">
                            <span class="input-with-icon">
                                <input type="text" class="form-control" name="email" id="email" placeholder="Email or Username" autocomplete="off" value="<?php if(isset($email)){echo $email;}?>">
                                <i class="fa fa-envelope"></i>
                            </span>
                            <span class="error"><?php if(isset($email_error)){echo $email_error;}?></span>
                        </div>
                        <div class="form-group">
                            <span class="input-with-icon">
                                <input type="password" name="password" class="form-control"   placeholder="Password"  autocomplete="off" id="myInput">
                                <i class="fa fa-key"></i>
                            </span>
                             <span class="error"><?php if(isset($password_error)){echo $password_error;}?></span>
                            <br>
                             
                           <!--  <input style="height: 12px;
                            width: 21px;"class="check" type="checkbox" onclick="myFunction()"><span style=" font-size: 14px;
                               margin-left: 15px;
                            color: #2828fd;" > 
                             

                                                        
                            </style> -->
                           <span style="font-size: 25px;cursor: pointer;"id="btn-imoji" onclick="pass(this)">   
                           &#128584;</span> Show Password
                         </span>    
                           <br>
                    
                        </div>
                        <div class="form-group">
                            <div class="checkbox-custom checkbox-primary">
                                <input type="checkbox" id="remember-me" value="option1" name="checked">
                                <label class="check" for="remember-me">Remember me</label>
                            </div>
                            <?php if(isset($errors)){echo $errors;}?>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="signin" value="Sign In" class="form-control btn-primary" >
                        </div>
                        <div class="form-group text-center">
                            <a href=" forgot_password.php">Forgot password?</a>
                            <hr/>
                             <span>Don't have an account?</span>
                            <a href="register.php" class="btn btn-block mt-sm">Register</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
</div>
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
    </div>
</div>
</div>
</section>
<section class="contact-us" id="contact" style="padding: 1px 0px 0px 0px;">
     
     <div class="footer" style="text-align: center;
   
     border-top: 1px solid rgba(250,250,250,0.15);">
      <p>© 2022 DIU Library. 
            </p>
     </div>
   </section>
<!--BASIC scripts--> 
<!-- ========================================================= -->
<script src="../assets/vendor/jquery/jquery-1.12.3.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/vendor/nano-scroller/nano-scroller.js"></script>
<!--TEMPLATE scripts-->
<!-- ========================================================= -->
<script src="../assets/javascripts/template-script.min.js"></script>
<script src="../assets/javascripts/template-init.min.js"></script>
<!-- SECTION script and examples-->
<!-- ========================================================= -->
<script>
 
//  function myFunction() {
//   var x = document.getElementById("myInput");
//   if (x.type === "password") {
//     x.type = "text";
//   } else {
//     x.type = "password";
//   }
// }   
var a=0;
function pass()
{
    if(a==0){
        document.getElementById('btn-imoji').innerHTML='&#128584;';
        document.getElementById('myInput').type='text';
        a=1;
    }else{
          document.getElementById('btn-imoji').innerHTML='&#128586;';
                  document.getElementById('myInput').type='password';
        a=0;
    }
}


document.addEventListener("contextmenu", function(e){
    e.preventDefault();
});
document.onkeydown = function(e){
    if(event.keyCode == 123){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.keyCode == "U".charCodeAt(0)){
        return false;
    }
}
</script>
 
    
 
</body>

 
</html>
<?php
ob_end_flush();



?>