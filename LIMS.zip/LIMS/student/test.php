 <?php
 include 'header.php';
 ?>
<!-- ========================================================= -->
 <div class="content">
                <div class="content-header">
                    <!-- leftside content header -->
                    <div class="leftside-content-header">
                        <ul class="breadcrumbs">
                            <li><i class="fa fa-home" aria-hidden="true"></i><a href="#">Dashboard</a></li>
                        <li><i class="fa fa-home" aria-hidden="true"></i><a href="#">Insert Info</a></li>
                        </ul>
                        <ul>
                        	
                        </ul>
                    </div>
                </div>
              
  <?php
 include 'footer.php';
 ?>