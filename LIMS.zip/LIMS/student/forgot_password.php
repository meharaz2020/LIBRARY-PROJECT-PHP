<?php
ob_start();
include '../dbcon.php';

 

?>


<?php
 
if(isset($_POST['Submit'])){

     $email           =$_POST['email'];
      $password        =$_POST['password'];
      $cpassword        =$_POST['cpassword'];
       $pass=password_hash($password, PASSWORD_DEFAULT); 
        $email_check= mysqli_query($db,"SELECT * FROM students WHERE email = '$email' ");
         if(mysqli_num_rows($email_check) > 0){
            $row = mysqli_fetch_assoc($email_check);

                          if(strlen($password)>7){
                            if(!$cpassword == ""){
                                        if($password == $cpassword){
                                              

                                                $query1="UPDATE students SET password='$pass' WHERE email = '$email'";
                                                $query_run=mysqli_query($db,$query1);
                                                if($query_run){
                                                     $update_sucess="Password update sucessfully";
                                                     echo "<script>window.location='forgot_password.php'</script>";

                                                }else{
                                                    $update_error="Password not update!";
                                                }


                                                


                                            }else{
                                            $confirms_password_error= "Password not match";
                                        }

                                    }else{
                                        $confirm_password_error= "Confirm Password fild is required";
                                    }



                             }else{
                                  $rpasseord_error= "Password must be 8 character"; 
                                }
         }else{
            $email_error="Wrong email or username id";
         }
   
}else{
    //not connect
}




?>


<!doctype html>
<html lang="en" class="fixed accounts forgot-password">


<!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/pages_forgot-password.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:06:17 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
     <!-- Bootstrap core CSS -->
     <link href="../index/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    
    <!--BASIC css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/vendor/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="../assets/vendor/animate.css/animate.css">
    <script src="../assets/javascripts/fontawesome.js"></script>
    <!--SECTION css-->
    <!-- ========================================================= -->
    <!--TEMPLATE css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../assets/stylesheets/css/style.css">


    <link rel="stylesheet" href="../index/assets/css/fontawesome.css">
    <link rel="stylesheet" href="../index/assets/css/templatemo-edu-meeting.css">
    <link rel="stylesheet" href="../index/assets/css/owl.css">
    <link rel="stylesheet" href="../index/assets/css/lightbox.css">
    <link rel="icon"  href="../index/title.jpg">  
    <title>Forgot Password</title>
    <style >
        .error{
  color: red;
  font-style: italic;
   
  font-weight: bold;

}

a:hover{
    background-color: transparent !important;
}
 
 /* .bg-img{
    max-width: 100%;
    max-height: 100%;
    background-image: url(../image/bg1.jpg);
    background-position: center;
    background-attachment: fixed;
    background-blend-mode: color-dodge;
    background-repeat: no-repeat;
 } */
 
   .heading-pagess{
    background-image: url(../index/fp.jpg) !important;
    background-position: top !important;
    background-repeat: no-repeat !important;
    background-size: cover !important;
    padding-top: 230px !important;
    padding-bottom:0 !important;
    text-align: center !important;
   }
   .header-area .main-nav .logo{
       line-height:0 !important;
       padding-top: 20px;
   }
   .header-area .main-nav .nav li a {
    line-height:0 !important;

   }
   body{
    background: none !important;
   }
   .header-area .main-nav .nav li {
 padding-left: 0 !important;
     padding-right: 0 !important; 
}
    
        
    </style>

</head>

<body>
<!-- Sub Header -->
<div class="sub-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-sm-8">
          <div class="left-content">
            <p>Daffodil<em> International</em> University</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-4">
          <div class="right-icons">
            <ul>
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-behance"></i></a></li>
              <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky fixed-top">
      <div class="container">
          <div class="row">
              <div class="col-12">
                  <nav class="main-nav">
                      <!-- ***** Logo Start ***** -->
                     <!-- ***** Logo Start ***** -->
                     <a href="../index/index.html" class="logo">
                          DIU Library
                      </a>
                      <!-- ***** Logo End ***** -->
                      <!-- ***** Menu Start ***** -->
                      <ul class="nav">
                          <li><a href="../index/index.php"  >Home</a></li>
                          <!-- <li><a href="meetings.html">Meetings</a></li> -->
                         
                          <!-- <li class="has-sub">
                              <a href="javascript:void(0)">Pages</a>
                              <ul class="sub-menu">
                                  <li><a href="meetings.html">Upcoming Meetings</a></li>
                                  <li><a href="meeting-details.html">Meeting Details</a></li>
                              </ul>
                          </li> -->
                          <li><a href="../index/book.php">Books</a></li> 
                          <li><a href="../index/upcoming.php">Upcoming Books</a></li> 
                          <li ><a href="../index/contact.php">Contact Us</a></li> 
                          <li class=""><a href="../student/signin.php" >Log In</a></li>
                      </ul>        
                      <a class='menu-trigger'>
                          <span>Menu</span>
                      </a>
                      <!-- ***** Menu End ***** -->
                  </nav>
              </div>
          </div>
      </div>
  </header>
  <!-- ***** Header Area End ***** -->

 <section class="heading-page header-text heading-pagess" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          
          <h2>Forgot Password</h2>
        </div>
      </div>
    </div>
  </section> 






  <section class="our-courses" id="courses"
  
  style="padding-bottom:0px !important; padding-top:0px !important"
  >

    <div class="container"> 


<div class="wrap">
    <!-- page BODY -->
    <!-- ========================================================= -->
    <div class="page-body  animated slideInDown">
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
        <!--LOGO-->
        <div class="col-sm-12 col-lg-12" style="text-align:center;">
                 <?php if(isset($update_sucess)){echo '<p class="alert alert-success" role="alert col-sm-4 offset-sm-3">'.$update_sucess.'</p>';}?> 
            </div>
        <div class="col-lg-12">
            <div class="col-lg-6 col-md-6">
               <div class="row">
                   <img src="s2.png" alt="" style="padding-right: 79px;">
               </div>
            </div>
            <div class="box col-lg-6 col-md-6" style="margin-bottom: 148px;">
            <!--FORGOT PASSWPRD FORM-->
            <div class="panel mb-none">
                <div class="panel-content bg-scale-0">
                    <div class="col-sm-12 offset-sm-6">
                 <?php //if(isset($update_sucess)){echo '<p class="alert alert-success" role="alert col-sm-4 offset-sm-3">'.$update_sucess.'</p>';}?> 
            </div>
            <div class="col-sm-12 offset-sm-6">
                 <?php if(isset($update_error)){echo '<p class="alert alert-danger" role="alert col-sm-4 offset-sm-3">'.$update_error.'</p>';}?>
             </div>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <!-- <h4 class="text-center">Forgot your password?</h4>  -->
                        <div class="form-group mt-md">
                                <span class="input-with-icon">
                                        <input type="text" class="form-control" id="email" placeholder="Enter your email"autocomplete="off" name="email" value="<?php if(isset($email)){echo $email;}?>">
                                        <i class="fa fa-envelope"></i>
                                    </span>
                                    <span class="error"><?php if(isset($email_error)){echo $email_error;}?></span>
                        </div>
                           <div class="form-group mt-md">
                                <span class="input-with-icon">
                                        <input type="password" class="form-control"   placeholder="New Password"autocomplete="off" name="password"    >
                                        <i class="fas fa-key"></i>
                                    </span>
                                    <span class="error"><?php if(isset($rpasseord_error)){echo $rpasseord_error;}?></span>
                                    
                        </div>
                        <div class="form-group mt-md">
                                <span class="input-with-icon">
                                        <input type="password" class="form-control"  placeholder="Confirm Password"autocomplete="off" name="cpassword" id="myInput" >
                                        <i class="fas fa-key"></i>
                                    </span>
                                    <span class="error"><?php if(isset($confirm_password_error)){echo $confirm_password_error;}?></span>
                                    <span class="error"><?php if(isset($confirms_password_error)){echo $confirms_password_error;}?></span>
                                    <span class="error"><?php if(isset($password_error)){echo $password_error;}?></span>
                                    <br>
                            
                            <input style="height: 12px;
                            width: 21px;"class="check" type="checkbox" onclick="myFunction()"><span style=" font-size: 14px;
                               margin-left: 15px;
                            color: #2828fd;" >
                                                        
                            </style>Show Password
                        </div>
                          
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block " name="Submit">Submit</button>
                        </div>
                        <div class="form-group text-center">
                            You remembered?, <a href="signin.php">Sign in!</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
    </div>
</div>

</div>
</div>
 
</section>
<section class="contact-us" id="contact" style="padding: 1px 0px 0px 0px;">
     
     <div class="footer" style="text-align: center;
   
     border-top: 1px solid rgba(250,250,250,0.15);">
      <p>© 2022 DIU Library. 
            </p>
     </div>
   </section>
<!--BASIC scripts-->
<!-- ========================================================= -->
<script src="../assets/vendor/jquery/jquery-1.12.3.min.js"></script>
<script src="../assets/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/vendor/nano-scroller/nano-scroller.js"></script>
<!--TEMPLATE scripts-->
<!-- ========================================================= -->
<script src="../assets/javascripts/template-script.min.js"></script>
<script src="../assets/javascripts/template-init.min.js"></script>
<!-- SECTION script and examples-->
<script>
 
 function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}  



document.addEventListener("contextmenu", function(e){
    e.preventDefault();
});
document.onkeydown = function(e){
    if(event.keyCode == 123){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)){
        return false;
    }
    if(e.ctrlKey && e.keyCode == "U".charCodeAt(0)){
        return false;
    }
}

</script>
<!-- ========================================================= -->
</body>


<!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/pages_forgot-password.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:06:17 GMT -->
</html>
<?php
ob_end_flush();


?>