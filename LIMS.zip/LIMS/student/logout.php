<?php


ob_start();
session_start();
session_destroy();
header("Location:../index/index.php");
ob_end_flush();
?>